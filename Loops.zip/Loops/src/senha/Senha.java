package senha;

import java.util.Scanner;

public class Senha {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);
		int senha = 1234;
		int input;
		
		System.out.println ("Validador de senhas!");
		System.out.println ("Informe a senha correta ");
		input = scanner.nextInt();
		
		while (input != senha) {
			System.out.println ("senha incorreta, tente novamente");
			System.out.println ("Informe a senha correta ");
			input = scanner.nextInt();
		}
		System.out.println("Acesso concedido");
        scanner.close();
	}
}