package medianotas;

import java.util.Scanner;

public class MediaNotas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double somaNotas = 0;
        int quantidadeNotas = 0;
        String continuar;

        do {
            System.out.println("Informe uma nota (0 a 10): ");
            double nota = scanner.nextDouble();

            if (nota >= 0 && nota <= 10) {
                somaNotas += nota;
                quantidadeNotas++;
            } else {
                System.out.println("Nota inválida. Digite um valor entre 0 e 10.");
            }

            System.out.println("Deseja inserir outra nota? (s/n)");
            scanner.nextLine(); 
            continuar = scanner.nextLine();

        } while (continuar.equalsIgnoreCase("s"));

        if (quantidadeNotas > 0) {
            double media = somaNotas / quantidadeNotas;
            System.out.printf("Média das notas: ", media);
        } else {
            System.out.println("Nenhuma nota válida foi inserida.");
        }
        scanner.close();
    }
}