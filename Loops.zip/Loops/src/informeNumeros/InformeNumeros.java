package informeNumeros;

import java.util.Scanner;

public class InformeNumeros {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);
		int i = 0;
		int numero;
				
		
		System.out.println ("===== acumulador de numeros positivos ! =====");
		System.out.println ("Insira valores");
		numero = scanner.nextInt();
		
		while (numero >= 0) {
			i += numero;
			System.out.println ("Insira valores");
			numero = scanner.nextInt();
		}
			if(numero < 0) {
				System.out.println ("numero negativo! programa encerrado!!");
				}
			System.out.println ("A soma dos numeros digitados é " + i);
			scanner.close();
		}
		}

