package loopsfor;

public class Array {
	 int[] numeros = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
     int resultado = 0;

     for (int i = 0; i < numbers.length; i++) {
         resultado += numeros[i];
     }
     System.out.println ("A soma dos elementos do vetor é: " + resultado);
}
}
