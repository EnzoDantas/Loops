package loopsfor;

import java.util.Scanner;

public class Fatorial {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        System.out.println("Digite um número inteiro positivo: ");
	        int numeros = scanner.nextInt();
	        
	        if (numeros < 0) {
	            System.out.println("O número deve ser positivo!");
	            
	        } else {
	            long factorial = 1;
	            for (int i = 1; i <= numeros; i++) {
	                factorial *= i;
	            }
	            System.out.println("O fatorial de " + numeros + " é: " + factorial);
	        }
	        scanner.close();
	}
}